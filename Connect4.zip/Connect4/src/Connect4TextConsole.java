/**Connect4TextConsole class displays mechanics for viable 6x7 Connect 4 game mecahnics and current state of board for player knowledge
 * turn, player, and current_board are public methods that can be illustrated for current game status
 * @author Tristen Young
 * @version 1.0
 *
 */
import java.util.Scanner;

public class Connect4TextConsole extends Connect4 {

    /**Displays the current state of Connect 4 board
     *
     * @param current_board
     * @return void
     */
    public static void display(char[][] current_board){
        System.out.println(" 1 2 3 4 5 6 7");
        System.out.println("---------------");
        for (int row = 1; row < current_board.length; row++){
            System.out.print("|");
            for (int col = 1; col < current_board[1].length; col++){
                System.out.print(current_board[row][col]);
                System.out.print("|");
            }
            System.out.println();
            System.out.println("---------------");
        }
        System.out.println(" 1 2 3 4 5 6 7 \n");
    }

    /**Method allows for the running of a new Connect 4 game
     *
     * @param args
     */
    public static void main(String[] args) {

        Connect4ComputerPlayer computer = new Connect4ComputerPlayer();
        Scanner scan = new Scanner(System.in);

        System.out.println("Please enter 1 to lauch gui or 2 to play in console");
        if(playGUI()){
            Connect4GUI.main(null);
        }

        System.out.println("Please enter 1 to player computer or 2 to play human");
        if(playMode()) {

            display(current_board);
            while(!winCondition()) {
                move();
                if(!isWinner(player, current_board)) {
                    computer.computerIntelligence();
                }
                display(current_board);
            }

            if (turn == 42) {
                System.out.println("Tie game");
            }else if (player=='X'){
                System.out.println("Player 1 won");
            }else{
                System.out.println("Computer won");
            }
        }else {

            display(current_board);
            while(!winCondition()) {
                move();
                display(current_board);
            }

            if (turn == 42) {
                System.out.println("Tie game");
            }else if (player=='X'){
                System.out.println("Player 1 won");
            }else{
                System.out.println("Player 2 won");
            }
        }
    }
}